function generateEmail() {
  const firstNames = ['meong', 'miskin', 'nabrak', 'anggora', 'liar', 'nyasar', 'gendut', 'manja', 'nakal', 'lapar'];
  const lastNames = ['hero', 'meow', 'yawn', 'paw', 'scratch', 'tail', 'hunter', 'purr', 'zoom', 'boss'];

  const randomName = `${firstNames[Math.floor(Math.random() * firstNames.length)]}${lastNames[Math.floor(Math.random() * lastNames.length)]}`;
  const domain = 'kucingmail.my.id';
  const email = `${randomName}@${domain}`;

  localStorage.setItem('myEmail', email);

  document.getElementById('emailDisplay').innerText = `📩 Email kamu: ${email}`;
  document.getElementById('inboxLink').href = `inbox.html`;
  document.getElementById('inboxLink').style.display = 'inline';
}
