require('dotenv').config();
const express = require('express');
const cors = require('cors');
const { MongoClient } = require('mongodb');
const { getInboxMessages } = require('./inbox/controller');

const app = express();
app.use(cors());
app.use(express.json()); // ⬅️ Wajib untuk parsing body JSON

const client = new MongoClient(process.env.MONGO_URI);
const dbName = 'kucingmail';

// 📬 Ambil semua pesan
app.get('/api/inbox', async (req, res) => {
  const user = req.query.user;
  if (!user) return res.status(400).json({ error: 'User is required' });

  try {
    const db = client.db(dbName);
    const messages = await getInboxMessages(db, user);
    res.json(messages);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Something went wrong' });
  }
});

// 📨 Simpan pesan baru
app.post('/api/inbox', async (req, res) => {
  const { user, subject, from, body } = req.body;
  if (!user || !subject || !from || !body) {
    return res.status(400).json({ error: 'All fields are required' });
  }

  try {
    const db = client.db(dbName);
    const collection = db.collection('messages');
    await collection.insertOne({
      user,
      subject,
      from,
      body,
      createdAt: new Date() // ⏰ Wajib agar TTL Index bekerja
    });
    res.status(201).json({ message: 'Message stored successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to store message' });
  }
});

app.listen(3000, () => {
  console.log('🚀 Server running on http://localhost:3000');
});
